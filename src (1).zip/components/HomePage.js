import React from 'react';
import CardSection from './CardSection';
import foodItems from './foodData';
import "./Homepage.css";
import Card from './Card';
import "./Card.css"

class HomePage extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      currentCardIndex: 0,
    };
  }
  handleNavChange= () => {
    for{x in }
    
    
  }
  handleCardChange = (change) => {
    const { currentCardIndex } = this.state;
    const newIndex = currentCardIndex + change;

    if (newIndex >= 0 && newIndex < foodItems.length) {
      this.setState({ currentCardIndex: newIndex });
    }
  };

  render() {
    const { currentCardIndex } = this.state;
    const currentFoodItem = foodItems[currentCardIndex];
  
    return (
      <div className="homepage-container">
      
        
        <div className="card-container">
          <div className="card-column">
            <Card
              name={currentFoodItem.name}
              image={currentFoodItem.image}
              description={currentFoodItem.description}
              handleCardChange={this.handleCardChange}
              handleNavChange = {this.handleNavChange(foodItems[(currentCardIndex)])}

            />
            <Card
              name={foodItems[(currentCardIndex + 1) % foodItems.length].name}
              image={foodItems[(currentCardIndex + 1) % foodItems.length].image}
              description={foodItems[(currentCardIndex + 1) % foodItems.length].description}
              handleCardChange={this.handleCardChange}              
              handleNavChange = {this.handleNavChange(foodItems[(currentCardIndex +1)])}

            />
            
             <Card
              name={foodItems[(currentCardIndex + 2) % foodItems.length].name}
              image={foodItems[(currentCardIndex + 2) % foodItems.length].image}
              description={foodItems[(currentCardIndex + 2) % foodItems.length].description}
              handleCardChange={this.handleCardChange}
              handleNavChange = {this.handleNavChange(foodItems[(currentCardIndex +2)])}
            />
     
          </div>
        </div>
        <CardSection foodItems={foodItems} handleCardChange={this.handleCardChange} />
      </div>
    );
  }
} 
  export default HomePage;