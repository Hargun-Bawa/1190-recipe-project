import React from 'react';

class SignInPopup extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      username: '',
      password: '',
    };
  }

  handleInputChange = (event) => {
    this.setState({
      [event.target.name]: event.target.value,
    });
  };

  handleSignIn = () => {
    const { username } = this.state;
    // Perform sign-in logic and store user preferences
    // Here you can create an object to store user preferences
    const userPreferences = [] 
      
      // Add more preferences as needed
    ;

    // Pass the user preferences to the parent component
    this.props.onSignIn(userPreferences);
  };

  render() {
    return (
      <div className="popup">
        <div className="popup-inner">
          <h3>Sign In</h3>
          <input
            type="text"
            name="username"
            placeholder="Username"
            value={this.state.username}
            onChange={this.handleInputChange}
          />
       
        
          <button onClick={this.handleSignIn}>Sign In</button>
        </div>
      </div>
    );
  }
}

export default SignInPopup;