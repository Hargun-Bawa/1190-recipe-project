import React from 'react';
import Card from './Card';
import foodItems from './foodData';

const CardSection = () => {
  return (
    <div className="card-section">
      {foodItems.map((foodItem, index) => (
        <Card
          key={index}
          name={foodItem.name}
          image={foodItem.image}
          description={foodItem.description}
        />
      ))}
    </div>
  );
};

export default CardSection;
