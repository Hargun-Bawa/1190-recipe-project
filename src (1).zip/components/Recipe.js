import React from 'react';
import Header from './Header';
import foodItems from './foodData';

import HorizontalMenu from './HorizontalMenu';

class Recipe extends React.Component {
    render() {
    return(
        <div className= "test">

            <Header></Header>
            <HorizontalMenu></HorizontalMenu>
            <p>hi</p>
        </div>
    

    );
    }
}
export default Recipe;